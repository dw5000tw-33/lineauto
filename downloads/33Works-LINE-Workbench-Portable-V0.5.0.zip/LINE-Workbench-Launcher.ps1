﻿# 33 Works LINE Workbench V0.5.0 - licensed launcher
# This launcher intentionally contains no LINE automation core.

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$script:BaseDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:ConfigPath = Join-Path $script:BaseDir 'config.json'
$script:ConfigExamplePath = Join-Path $script:BaseDir 'config.example.json'

function Read-LauncherConfig {
    $path = if (Test-Path -LiteralPath $script:ConfigPath) { $script:ConfigPath } else { $script:ConfigExamplePath }
    if (-not (Test-Path -LiteralPath $path)) { throw '找不到 config.json 或 config.example.json。' }
    $config = Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json
    if ([string]::IsNullOrWhiteSpace([string]$config.apiBaseUrl)) { throw 'apiBaseUrl 尚未設定。' }
    $uri = [Uri]([string]$config.apiBaseUrl)
    if ($uri.Scheme -ne 'https' -and -not ($uri.Scheme -eq 'http' -and @('localhost','127.0.0.1') -contains $uri.Host)) {
        throw '正式 API 必須使用 HTTPS；HTTP 只允許 localhost 測試。'
    }
    return $config
}

function Get-DeviceId {
    $machineGuid = ''
    try { $machineGuid = [string](Get-ItemPropertyValue -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Cryptography' -Name MachineGuid) } catch {}
    $systemUuid = ''
    try { $systemUuid = [string](Get-CimInstance -ClassName Win32_ComputerSystemProduct -ErrorAction Stop).UUID } catch {}
    $source = "33works-line-workbench|$machineGuid|$systemUuid"
    $bytes = [Text.Encoding]::UTF8.GetBytes($source)
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-', '').ToLowerInvariant() }
    finally { $sha.Dispose() }
}

function Get-Sha256([string]$Path) {
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function New-Nonce {
    $bytes = New-Object byte[] 18
    $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
    try { $rng.GetBytes($bytes) } finally { $rng.Dispose() }
    return [Convert]::ToBase64String($bytes).TrimEnd('=').Replace('+','-').Replace('/','_')
}

function Invoke-Authorization([string]$Code, $Config, [string]$DeviceId) {
    $body = @{
        code       = $Code
        deviceId   = $DeviceId
        deviceName = [string]$env:COMPUTERNAME
        appVersion = [string]$Config.appVersion
        nonce      = New-Nonce
    } | ConvertTo-Json -Compress
    $endpoint = ([string]$Config.apiBaseUrl).TrimEnd('/') + '/api/v1/license/verify'
    try {
        return Invoke-RestMethod -Uri $endpoint -Method Post -ContentType 'application/json; charset=utf-8' -Body $body -TimeoutSec 30
    }
    catch {
        $reason = $null
        try {
            $response = $_.Exception.Response
            if ($response) {
                $stream = $response.GetResponseStream()
                $reader = New-Object IO.StreamReader($stream)
                try { $reason = (($reader.ReadToEnd() | ConvertFrom-Json).reason) } finally { $reader.Dispose(); $stream.Dispose() }
            }
        } catch {}
        if ($reason) { throw "授權未通過：$reason" }
        throw
    }
}

function Invoke-CorePart($Authorization, $Config, [string]$DeviceId) {
    if (-not $Authorization.core -or [string]::IsNullOrWhiteSpace([string]$Authorization.core.downloadUrl)) {
        throw '授權服務沒有提供 B Part 下載資訊。'
    }
    $downloadUrl = [string]$Authorization.core.downloadUrl
    if (-not [Uri]::IsWellFormedUriString($downloadUrl, [UriKind]::Absolute)) {
        $downloadUrl = ([string]$Config.apiBaseUrl).TrimEnd('/') + '/' + $downloadUrl.TrimStart('/')
    }
    $tempDir = Join-Path ([IO.Path]::GetTempPath()) ('33works-line-' + [Guid]::NewGuid().ToString('N'))
    [IO.Directory]::CreateDirectory($tempDir) | Out-Null
    $tempCore = Join-Path $tempDir 'authorized-core.ps1'
    try {
        $headers = @{ Authorization = 'Bearer ' + [string]$Authorization.accessToken; 'X-Device-Id' = $DeviceId }
        Invoke-WebRequest -UseBasicParsing -Uri $downloadUrl -Headers $headers -OutFile $tempCore -TimeoutSec 60
        $actualHash = Get-Sha256 $tempCore
        $expectedHash = ([string]$Authorization.core.sha256).ToLowerInvariant()
        if ($actualHash -ne $expectedHash) { throw 'B Part 完整性驗證失敗，本次不執行。' }
        $arguments = @(
            '-NoProfile', '-ExecutionPolicy', 'Bypass', '-STA', '-File', ('"' + $tempCore + '"'),
            '-LicenseToken', ('"' + [string]$Authorization.accessToken + '"'),
            '-ApiBaseUrl', ('"' + ([string]$Config.apiBaseUrl).TrimEnd('/') + '"'),
            '-DeviceId', ('"' + $DeviceId + '"')
        ) -join ' '
        $process = Start-Process -FilePath 'powershell.exe' -ArgumentList $arguments -PassThru -Wait
        if ($process.ExitCode -ne 0) { throw "B Part 結束碼為 $($process.ExitCode)。" }
    }
    finally {
        if (Test-Path -LiteralPath $tempCore) { Remove-Item -LiteralPath $tempCore -Force -ErrorAction SilentlyContinue }
        if (Test-Path -LiteralPath $tempDir) { Remove-Item -LiteralPath $tempDir -Force -ErrorAction SilentlyContinue }
    }
}

function Convert-ToFriendlyError([string]$Message) {
    if ($Message -match 'DEVICE_MISMATCH') { return '這組通行碼已綁定其他電腦，請按「問題回報」聯絡官方 LINE。' }
    if ($Message -match 'EXPIRED') { return '通行碼已到期，請按「問題回報」聯絡官方 LINE。' }
    if ($Message -match 'DISABLED') { return '通行碼目前已停用，請按「問題回報」聯絡官方 LINE。' }
    if ($Message -match 'CODE_NOT_FOUND|INVALID_CODE') { return '找不到這組通行碼，請確認後再試一次。' }
    if ($Message -match 'RATE_LIMITED') { return '嘗試次數過多，請稍候一分鐘再試。' }
    if ($Message -match 'PRODUCT_NOT_ALLOWED') { return '這組通行碼不適用目前版本，請聯絡官方 LINE。' }
    if ($Message -match 'timed out|timeout|無法連線|連線失敗|The remote name|NameResolutionFailure') { return '目前無法連線到驗證服務，請檢查網路後再試一次。' }
    if ($Message -match 'B Part|完整性|結束碼|download|下載') { return '工作台啟動失敗，請按「問題回報」聯絡官方 LINE。' }
    return '驗證失敗，請確認通行碼與網路後再試一次。'
}

function Start-ShellOpen([string]$Target) {
    $startInfo = New-Object Diagnostics.ProcessStartInfo
    $startInfo.FileName = $Target
    $startInfo.UseShellExecute = $true
    [Diagnostics.Process]::Start($startInfo) | Out-Null
}

function Open-OfficialLine {
    try {
        if ([string]::IsNullOrWhiteSpace([string]$config.officialLineUrl)) { throw '官方 LINE 連結尚未設定。' }
        Start-ShellOpen ([string]$config.officialLineUrl)
    }
    catch {
        [Windows.Forms.MessageBox]::Show(
            '無法自動開啟 LINE，請在 LINE 搜尋官方帳號：@791gqyyp',
            'AD 廣告管理助手',
            [Windows.Forms.MessageBoxButtons]::OK,
            [Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
    }
}

function Open-SupportPage {
    $supportUrl = 'https://payment.ecpay.com.tw/QuickCollect/PayData?UV8kunudvpag0i8o5BpVheak%2blji826yhTg%2f3%2bI2iDo%3d'
    try {
        Start-ShellOpen $supportUrl
    }
    catch {
        [Windows.Forms.MessageBox]::Show(
            '目前無法開啟自願支持頁面，請稍後再試。',
            'LINE 自動化工作台',
            [Windows.Forms.MessageBoxButtons]::OK,
            [Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
    }
}

function Open-UserGuide {
    $htmlGuide = Join-Path $script:BaseDir '使用說明.html'
    $textGuide = Join-Path $script:BaseDir '使用說明.txt'

    $guideForm = New-Object Windows.Forms.Form
    $guideForm.Text = 'LINE 自動化工作台｜操作說明'
    $guideForm.Size = New-Object Drawing.Size(660, 650)
    $guideForm.StartPosition = 'CenterParent'
    $guideForm.FormBorderStyle = 'FixedDialog'
    $guideForm.MaximizeBox = $false
    $guideForm.MinimizeBox = $false
    $guideForm.BackColor = [Drawing.Color]::FromArgb(245, 247, 251)
    $guideForm.Font = New-Object Drawing.Font('Microsoft JhengHei UI', 10)

    $guideTitle = New-Object Windows.Forms.Label
    $guideTitle.Text = '第一次使用，請照這個順序操作'
    $guideTitle.Font = New-Object Drawing.Font('Microsoft JhengHei UI', 17, [Drawing.FontStyle]::Bold)
    $guideTitle.ForeColor = [Drawing.Color]::FromArgb(14, 44, 93)
    $guideTitle.Location = New-Object Drawing.Point(28, 24)
    $guideTitle.Size = New-Object Drawing.Size(590, 38)
    $guideForm.Controls.Add($guideTitle)

    $guideText = New-Object Windows.Forms.RichTextBox
    $guideText.ReadOnly = $true
    $guideText.BorderStyle = 'None'
    $guideText.BackColor = [Drawing.Color]::White
    $guideText.ForeColor = [Drawing.Color]::FromArgb(21, 34, 60)
    $guideText.Location = New-Object Drawing.Point(28, 75)
    $guideText.Size = New-Object Drawing.Size(590, 450)
    $guideText.Font = New-Object Drawing.Font('Microsoft JhengHei UI', 11)
    $guideText.Text = @'
1｜先開啟 LINE 電腦版並完成登入

2｜回到啟動面板，輸入 7 碼通行碼，按「驗證並啟動」

3｜工作台開啟後，先按「連接 LINE」
    等畫面顯示已連接，再進行下一步

4｜依序設定「對象 → 內容 → 排程」

5｜送出前，再次核對群組或好友、訊息內容及傳送時間

排程執行期間：
• 電腦需保持開機、登入、未鎖定，並關閉睡眠
• LINE 電腦版與工作台都要保持開啟
• 若 LINE 尚未登入或尚未連接，工作台無法執行傳送
'@
    $guideForm.Controls.Add($guideText)

    $fullGuideButton = New-Object Windows.Forms.Button
    $fullGuideButton.Text = '開啟完整圖文說明'
    $fullGuideButton.Location = New-Object Drawing.Point(296, 546)
    $fullGuideButton.Size = New-Object Drawing.Size(190, 42)
    $fullGuideButton.BackColor = [Drawing.Color]::White
    $fullGuideButton.FlatStyle = 'Flat'
    $fullGuideButton.FlatAppearance.BorderColor = [Drawing.Color]::FromArgb(199, 210, 226)
    if (Test-Path -LiteralPath $htmlGuide) { $fullGuideButton.Tag = $htmlGuide }
    elseif (Test-Path -LiteralPath $textGuide) { $fullGuideButton.Tag = $textGuide }
    else { $fullGuideButton.Enabled = $false }
    $fullGuideButton.Add_Click({
        param($sender, $eventArgs)
        try { Start-ShellOpen ([string]$sender.Tag) }
        catch {
            [Windows.Forms.MessageBox]::Show(
                '無法開啟完整圖文說明，但上方的基本操作步驟仍可使用。',
                'LINE 自動化工作台',
                [Windows.Forms.MessageBoxButtons]::OK,
                [Windows.Forms.MessageBoxIcon]::Information
            ) | Out-Null
        }
    })
    $guideForm.Controls.Add($fullGuideButton)

    $closeGuideButton = New-Object Windows.Forms.Button
    $closeGuideButton.Text = '關閉'
    $closeGuideButton.Location = New-Object Drawing.Point(498, 546)
    $closeGuideButton.Size = New-Object Drawing.Size(120, 42)
    $closeGuideButton.BackColor = [Drawing.Color]::FromArgb(243, 182, 58)
    $closeGuideButton.FlatStyle = 'Flat'
    $closeGuideButton.FlatAppearance.BorderSize = 0
    $closeGuideButton.DialogResult = [Windows.Forms.DialogResult]::OK
    $guideForm.AcceptButton = $closeGuideButton
    $guideForm.CancelButton = $closeGuideButton
    $guideForm.Controls.Add($closeGuideButton)

    $guideForm.ShowDialog($form) | Out-Null
    $guideForm.Dispose()
}

function Set-Status([string]$Text, [Drawing.Color]$Color, [Drawing.Color]$Background) {
    $statusLabel.Text = $Text
    $statusLabel.ForeColor = $Color
    $statusPanel.BackColor = $Background
}

$config = Read-LauncherConfig
$deviceId = Get-DeviceId

$navy = [Drawing.Color]::FromArgb(14, 44, 93)
$blue = [Drawing.Color]::FromArgb(25, 76, 139)
$gold = [Drawing.Color]::FromArgb(243, 182, 58)
$goldHover = [Drawing.Color]::FromArgb(232, 163, 34)
$pageBackground = [Drawing.Color]::FromArgb(245, 247, 251)
$surface = [Drawing.Color]::White
$softSurface = [Drawing.Color]::FromArgb(241, 246, 252)
$textColor = [Drawing.Color]::FromArgb(21, 34, 60)
$mutedColor = [Drawing.Color]::FromArgb(97, 112, 138)
$borderColor = [Drawing.Color]::FromArgb(199, 210, 226)
$successColor = [Drawing.Color]::FromArgb(29, 119, 75)
$successBackground = [Drawing.Color]::FromArgb(232, 247, 238)
$warningColor = [Drawing.Color]::FromArgb(151, 95, 0)
$warningBackground = [Drawing.Color]::FromArgb(255, 247, 225)
$errorColor = [Drawing.Color]::FromArgb(178, 46, 46)
$errorBackground = [Drawing.Color]::FromArgb(253, 237, 237)
$supportGreen = [Drawing.Color]::FromArgb(6, 199, 85)
$supportGreenHover = [Drawing.Color]::FromArgb(0, 178, 74)

$form = New-Object Windows.Forms.Form
$form.Text = '33 Works｜LINE 自動化工作台 V0.5.0'
$form.StartPosition = 'CenterScreen'
$form.ClientSize = New-Object Drawing.Size(720, 660)
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.MinimizeBox = $true
$form.AutoScaleMode = [Windows.Forms.AutoScaleMode]::Dpi
$form.BackColor = $pageBackground
$form.Font = New-Object Drawing.Font('Microsoft JhengHei UI', 10)

$headerPanel = New-Object Windows.Forms.Panel
$headerPanel.Location = New-Object Drawing.Point(0, 0)
$headerPanel.Size = New-Object Drawing.Size(720, 140)
$headerPanel.BackColor = $navy
$form.Controls.Add($headerPanel)

$logoBox = New-Object Windows.Forms.PictureBox
$logoBox.Location = New-Object Drawing.Point(34, 24)
$logoBox.Size = New-Object Drawing.Size(92, 92)
$logoBox.SizeMode = [Windows.Forms.PictureBoxSizeMode]::Zoom
$logoPath = Join-Path $script:BaseDir 'logo.png'
if (Test-Path -LiteralPath $logoPath) {
    $logoBytes = [IO.File]::ReadAllBytes($logoPath)
    $logoStream = New-Object IO.MemoryStream -ArgumentList @(,$logoBytes)
    $sourceLogo = [Drawing.Image]::FromStream($logoStream)
    $logoBox.Image = New-Object Drawing.Bitmap -ArgumentList $sourceLogo
    $sourceLogo.Dispose()
    $logoStream.Dispose()
}
$headerPanel.Controls.Add($logoBox)

$title = New-Object Windows.Forms.Label
$title.Text = 'LINE 自動化工作台'
$title.Font = New-Object Drawing.Font('Microsoft JhengHei UI', 22, [Drawing.FontStyle]::Bold)
$title.ForeColor = [Drawing.Color]::White
$title.AutoSize = $true
$title.Location = New-Object Drawing.Point(150, 34)
$headerPanel.Controls.Add($title)

$subtitle = New-Object Windows.Forms.Label
$subtitle.Text = '輸入通行碼，開始使用'
$subtitle.Font = New-Object Drawing.Font('Microsoft JhengHei UI', 11)
$subtitle.ForeColor = [Drawing.Color]::FromArgb(220, 232, 250)
$subtitle.AutoSize = $true
$subtitle.Location = New-Object Drawing.Point(153, 82)
$headerPanel.Controls.Add($subtitle)

$versionBadge = New-Object Windows.Forms.Label
$versionBadge.Text = 'V0.5.0'
$versionBadge.Font = New-Object Drawing.Font('Microsoft JhengHei UI', 10, [Drawing.FontStyle]::Bold)
$versionBadge.ForeColor = [Drawing.Color]::White
$versionBadge.BackColor = $blue
$versionBadge.TextAlign = [Drawing.ContentAlignment]::MiddleCenter
$versionBadge.Location = New-Object Drawing.Point(596, 46)
$versionBadge.Size = New-Object Drawing.Size(82, 34)
$headerPanel.Controls.Add($versionBadge)

$codeLabel = New-Object Windows.Forms.Label
$codeLabel.Text = '7 碼通行碼'
$codeLabel.Font = New-Object Drawing.Font('Microsoft JhengHei UI', 11, [Drawing.FontStyle]::Bold)
$codeLabel.ForeColor = $textColor
$codeLabel.AutoSize = $true
$codeLabel.Location = New-Object Drawing.Point(42, 168)
$form.Controls.Add($codeLabel)

$codeHint = New-Object Windows.Forms.Label
$codeHint.Text = '大寫英文＋數字，例如：7K3M9XQ'
$codeHint.Font = New-Object Drawing.Font('Microsoft JhengHei UI', 9)
$codeHint.ForeColor = $mutedColor
$codeHint.AutoSize = $true
$codeHint.Location = New-Object Drawing.Point(150, 171)
$form.Controls.Add($codeHint)

$codeBox = New-Object Windows.Forms.TextBox
$codeBox.Location = New-Object Drawing.Point(42, 202)
$codeBox.Size = New-Object Drawing.Size(400, 40)
$codeBox.Font = New-Object Drawing.Font('Consolas', 16)
$codeBox.UseSystemPasswordChar = $true
$codeBox.CharacterCasing = 'Upper'
$codeBox.MaxLength = 7
$codeBox.BorderStyle = [Windows.Forms.BorderStyle]::FixedSingle
$form.Controls.Add($codeBox)

$verifyButton = New-Object Windows.Forms.Button
$verifyButton.Text = '驗證並啟動'
$verifyButton.Font = New-Object Drawing.Font('Microsoft JhengHei UI', 11, [Drawing.FontStyle]::Bold)
$verifyButton.Location = New-Object Drawing.Point(462, 198)
$verifyButton.Size = New-Object Drawing.Size(216, 48)
$verifyButton.FlatStyle = [Windows.Forms.FlatStyle]::Flat
$verifyButton.FlatAppearance.BorderSize = 0
$verifyButton.BackColor = $gold
$verifyButton.ForeColor = $textColor
$verifyButton.Cursor = [Windows.Forms.Cursors]::Hand
$verifyButton.Add_MouseEnter({ $verifyButton.BackColor = $goldHover })
$verifyButton.Add_MouseLeave({ $verifyButton.BackColor = $gold })
$form.Controls.Add($verifyButton)

$applyLink = New-Object Windows.Forms.LinkLabel
$applyLink.Text = '還沒有通行碼？前往官方 LINE 申請  →'
$applyLink.Font = New-Object Drawing.Font('Microsoft JhengHei UI', 10)
$applyLink.LinkColor = $blue
$applyLink.ActiveLinkColor = $navy
$applyLink.AutoSize = $true
$applyLink.Location = New-Object Drawing.Point(42, 260)
$applyLink.Cursor = [Windows.Forms.Cursors]::Hand
$applyLink.Add_LinkClicked({ Open-OfficialLine })
$form.Controls.Add($applyLink)

$statusPanel = New-Object Windows.Forms.Panel
$statusPanel.Location = New-Object Drawing.Point(42, 296)
$statusPanel.Size = New-Object Drawing.Size(636, 54)
$statusPanel.BackColor = $softSurface
$form.Controls.Add($statusPanel)

$statusLabel = New-Object Windows.Forms.Label
$statusLabel.Text = '尚未驗證。'
$statusLabel.Font = New-Object Drawing.Font('Microsoft JhengHei UI', 10)
$statusLabel.ForeColor = $mutedColor
$statusLabel.TextAlign = [Drawing.ContentAlignment]::MiddleLeft
$statusLabel.Location = New-Object Drawing.Point(16, 8)
$statusLabel.Size = New-Object Drawing.Size(604, 38)
$statusPanel.Controls.Add($statusLabel)

$guidePanel = New-Object Windows.Forms.Panel
$guidePanel.Location = New-Object Drawing.Point(42, 372)
$guidePanel.Size = New-Object Drawing.Size(636, 188)
$guidePanel.BackColor = $softSurface
$form.Controls.Add($guidePanel)

$guideTitle = New-Object Windows.Forms.Label
$guideTitle.Text = '使用前請確認'
$guideTitle.Font = New-Object Drawing.Font('Microsoft JhengHei UI', 14, [Drawing.FontStyle]::Bold)
$guideTitle.ForeColor = $textColor
$guideTitle.AutoSize = $true
$guideTitle.Location = New-Object Drawing.Point(24, 18)
$guidePanel.Controls.Add($guideTitle)

$guideTexts = @(
    'LINE 電腦版已登入',
    '執行期間保持開機、登入、未鎖定，並關閉睡眠',
    '傳送前再次核對對象、內容與排程'
)
for ($i = 0; $i -lt $guideTexts.Count; $i++) {
    $number = New-Object Windows.Forms.Label
    $number.Text = [string]($i + 1)
    $number.Font = New-Object Drawing.Font('Microsoft JhengHei UI', 9, [Drawing.FontStyle]::Bold)
    $number.ForeColor = $textColor
    $number.BackColor = $gold
    $number.TextAlign = [Drawing.ContentAlignment]::MiddleCenter
    $number.Location = New-Object Drawing.Point(28, (62 + ($i * 38)))
    $number.Size = New-Object Drawing.Size(27, 27)
    $guidePanel.Controls.Add($number)

    $guideLine = New-Object Windows.Forms.Label
    $guideLine.Text = $guideTexts[$i]
    $guideLine.Font = New-Object Drawing.Font('Microsoft JhengHei UI', 10)
    $guideLine.ForeColor = $textColor
    $guideLine.AutoSize = $true
    $guideLine.Location = New-Object Drawing.Point(70, (65 + ($i * 38)))
    $guidePanel.Controls.Add($guideLine)
}

$footerLine = New-Object Windows.Forms.Panel
$footerLine.Location = New-Object Drawing.Point(42, 586)
$footerLine.Size = New-Object Drawing.Size(636, 1)
$footerLine.BackColor = $borderColor
$form.Controls.Add($footerLine)

$currentVersion = New-Object Windows.Forms.Label
$currentVersion.Text = '目前版本：V0.5.0'
$currentVersion.Font = New-Object Drawing.Font('Microsoft JhengHei UI', 9)
$currentVersion.ForeColor = $mutedColor
$currentVersion.AutoSize = $true
$currentVersion.Location = New-Object Drawing.Point(42, 614)
$form.Controls.Add($currentVersion)

$supportButton = New-Object Windows.Forms.Button
$supportButton.Text = '自願支持'
$supportButton.Location = New-Object Drawing.Point(350, 604)
$supportButton.Size = New-Object Drawing.Size(100, 36)
$supportButton.FlatStyle = [Windows.Forms.FlatStyle]::Flat
$supportButton.FlatAppearance.BorderSize = 0
$supportButton.BackColor = $supportGreen
$supportButton.ForeColor = [Drawing.Color]::White
$supportButton.Cursor = [Windows.Forms.Cursors]::Hand
$supportButton.Add_MouseEnter({ $supportButton.BackColor = $supportGreenHover })
$supportButton.Add_MouseLeave({ $supportButton.BackColor = $supportGreen })
$supportButton.Add_Click({ Open-SupportPage })
$form.Controls.Add($supportButton)

$guideButton = New-Object Windows.Forms.Button
$guideButton.Text = '操作說明'
$guideButton.Location = New-Object Drawing.Point(464, 604)
$guideButton.Size = New-Object Drawing.Size(100, 36)
$guideButton.FlatStyle = [Windows.Forms.FlatStyle]::Flat
$guideButton.FlatAppearance.BorderColor = $borderColor
$guideButton.BackColor = $surface
$guideButton.ForeColor = $textColor
$guideButton.Cursor = [Windows.Forms.Cursors]::Hand
$guideButton.Add_Click({ Open-UserGuide })
$form.Controls.Add($guideButton)

$reportButton = New-Object Windows.Forms.Button
$reportButton.Text = '問題回報'
$reportButton.Location = New-Object Drawing.Point(578, 604)
$reportButton.Size = New-Object Drawing.Size(100, 36)
$reportButton.FlatStyle = [Windows.Forms.FlatStyle]::Flat
$reportButton.FlatAppearance.BorderColor = $borderColor
$reportButton.BackColor = $surface
$reportButton.ForeColor = $textColor
$reportButton.Cursor = [Windows.Forms.Cursors]::Hand
$reportButton.Add_Click({
    Open-OfficialLine
    Set-Status '已開啟官方 LINE，請輸入「問題回報」並附上畫面截圖。' $blue $softSurface
})
$form.Controls.Add($reportButton)

$verifyButton.Add_Click({
    $code = $codeBox.Text.Trim().ToUpperInvariant()
    if ($code -notmatch '^[A-Z0-9]{7}$') {
        Set-Status '請輸入 7 碼大寫英文與數字通行碼。' $errorColor $errorBackground
        $codeBox.Focus()
        return
    }

    $verifyButton.Enabled = $false
    $verifyButton.Text = '驗證中…'
    $codeBox.Enabled = $false
    Set-Status '正在驗證通行碼，請稍候…' $warningColor $warningBackground
    try {
        $authorization = Invoke-Authorization -Code $code -Config $config -DeviceId $deviceId
        if (-not $authorization.ok) { throw ('授權未通過：' + [string]$authorization.reason) }
        $expiryText = if ($authorization.license.expiresAt) { ([DateTimeOffset]::Parse([string]$authorization.license.expiresAt)).ToLocalTime().ToString('yyyy/MM/dd HH:mm') } else { '依官方設定' }
        Set-Status "驗證成功，有效至 $expiryText。正在啟動工作台…" $successColor $successBackground
        [Windows.Forms.Application]::DoEvents()
        Invoke-CorePart -Authorization $authorization -Config $config -DeviceId $deviceId
        Set-Status '工作台已關閉，可再次輸入通行碼啟動。' $successColor $successBackground
        $codeBox.Text = ''
    }
    catch {
        Set-Status (Convert-ToFriendlyError ([string]$_.Exception.Message)) $errorColor $errorBackground
    }
    finally {
        $verifyButton.Enabled = $true
        $verifyButton.Text = '驗證並啟動'
        $codeBox.Enabled = $true
        $codeBox.Focus()
    }
})

$form.AcceptButton = $verifyButton
$form.Add_Shown({ $codeBox.Focus() })
$form.Add_FormClosed({ if ($logoBox.Image) { $logoBox.Image.Dispose() } })
[void]$form.ShowDialog()

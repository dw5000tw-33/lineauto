﻿# 33 Works LINE Workbench - native EXE diagnostic bridge

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$baseDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$launcherPath = Join-Path $baseDir 'LINE-Workbench-Launcher.ps1'
$logPath = Join-Path $baseDir 'EXE-啟動錯誤.log'

try {
    if (-not (Test-Path -LiteralPath $launcherPath)) {
        throw '找不到 LINE-Workbench-Launcher.ps1。請確認 ZIP 已全部解壓縮，且四個檔案仍放在同一資料夾。'
    }

    & $launcherPath

    if (Test-Path -LiteralPath $logPath) {
        Remove-Item -LiteralPath $logPath -Force -ErrorAction SilentlyContinue
    }
}
catch {
    $details = @(
        "時間：$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
        "Windows PowerShell：$($PSVersionTable.PSVersion)"
        "錯誤：$($_.Exception.Message)"
        "位置：$($_.InvocationInfo.PositionMessage)"
        "完整資料："
        ($_ | Out-String)
    ) -join "`r`n"

    try {
        Set-Content -LiteralPath $logPath -Value $details -Encoding UTF8
    } catch {}

    try {
        Add-Type -AssemblyName System.Windows.Forms
        [Windows.Forms.MessageBox]::Show(
            "LINE 工作台啟動失敗。`r`n`r`n$($_.Exception.Message)`r`n`r`n已將詳細資料寫入：`r`n$logPath",
            '33 Works｜啟動錯誤',
            [Windows.Forms.MessageBoxButtons]::OK,
            [Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    } catch {}

    exit 1
}

